package day3;

//import java.util.ArrayList;
//import java.util.List;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
DataManager manager = new DataManager();
		String response;
		int choice,id=0,select_sort_id;
		String name,email;
		do {
			System.out.println("1.Add Data");
			System.out.println("2.Sort Data");
			System.out.println("3.Display Data");
			
			System.out.println("Enter your choice");
			
			choice = sc.nextInt();
			
			if(choice==1)
			{
				System.out.println("Enter Name");
				name = sc.next();
				System.out.println("Enter Email");
				email = sc.next();
				manager.add(new Teacher(++id,name,email));
			}
			else if(choice == 2)
			{
				System.out.println("Select sort id from below");
				System.out.println("1.Sort by id");
				System.out.println("2.Sort by name");
				System.out.println("3.Sort by email");
				
				select_sort_id = sc.nextInt();
				
				if(select_sort_id == 1)
				{
					manager.defaultSort();
				}
				else if(select_sort_id == 2)
				{
					manager.nameSort();
				}
				else
					manager.emailSort();
			}
			else if (choice == 3)
			{
				manager.print();
			}
			else
				System.out.println("You enter wrong choice please try again");
			System.out.println("Do you want to Continue [y/n]");
			response = sc.next();
		}while(response.equalsIgnoreCase("y"));
		
		sc.close();

		/*
		 * manager.add(new Teacher(1, "Ashish", "ashish@gmail.com")); manager.add(new
		 * Teacher(2, "Prem", "prem@gmail.com")); manager.add(new Teacher(4, "Anjali",
		 * "anjali@gmail.com")); manager.add(new Teacher(3, "Ratna",
		 * "ratna@gmail.com"));
		 * 
		 * System.out.println("Before sorting..."); manager.print();
		 * 
		 * System.out.println("After default sort..."); manager.defaultSort();
		 * manager.print();
		 * 
		 * 
		 * System.out.println("After name sort..."); manager.nameSort();
		 * manager.print();
		 */
		
		/*
		 * // List<String> artists = new ArrayList<>(); // List<String> goldenArtists =
		 * new ArrayList<>(); // // goldenArtists.add("R D Burman"); //
		 * goldenArtists.add("Lakshmikant Pyarelal"); //
		 * goldenArtists.add("Bappi Lahri"); // // artists.add("A R Rahman"); //
		 * artists.add("Pritam"); // artists.add(0, "Vishal Shekhar"); // // for(String
		 * artist : artists) { // System.out.println(artist.toUpperCase()); // } // //
		 * Iterator<String> itr = artists.iterator(); // while(itr.hasNext()) { //
		 * String artist = itr.next(); // System.out.println(artist.toLowerCase()); // }
		 */	
		
	}

}
