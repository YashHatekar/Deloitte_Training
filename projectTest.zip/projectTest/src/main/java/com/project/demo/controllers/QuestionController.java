package com.project.demo.controllers;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.project.demo.model.Question;
import com.project.demo.model.Test;


//import bootdemo.demo.NoteRepository;

@Controller
public class QuestionController {

	@Autowired
	private QuestionRepository questionRepo;
	
	@Autowired
	private TestRepository testRepo;
	
	@GetMapping("/testscreate")
	public String findAll(Model model){
		model.addAttribute("questions",questionRepo.findAll());
		return "testscreate";
	}

	

	@PostMapping("/testscreate")
	public String saveQuestion(@Valid Question question)
	{
		questionRepo.save(question);
		return "redirect:/testscreate";
	}
	
	@GetMapping("/questions/{id}")
	public Optional<Question> getQuestionById(@PathVariable(value="id")int quesId)
	{
		return questionRepo.findById(quesId);
	}
	
	
	
	@DeleteMapping("/questions/{id}")
	public ResponseEntity<?> delQuestion(@PathVariable(value="quesId")int id)
	{
		Optional<Question> ques=questionRepo.findById(id);
		if(ques.isPresent())
		{
			
			questionRepo.delete(ques.get());
		}
		return ResponseEntity.ok().build();
	}
}
