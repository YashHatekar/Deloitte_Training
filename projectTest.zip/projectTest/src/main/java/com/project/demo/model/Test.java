package com.project.demo.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "project_test")
public class Test {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "BOOT_TEST_SEQ")
	@SequenceGenerator(sequenceName = "customer_seq", allocationSize = 1, name = "BOOT_TEST_SEQ")
	@Column(name = "testId")
	private int testId;

	@Column(name = "testName")
	private String testName;

	@Column(name = "noOfQuestions")
	private int noOfQuestions;

	@Column(name = "totalMarks")
	private int totalMarks;

	@Column(name = "domain")
	private String domain;

	@ManyToMany
	@JoinTable(name = "test_questions", joinColumns = @JoinColumn(name = "testId"), inverseJoinColumns = @JoinColumn(name = "quesId"))
	private List<Question> questions;

	@OneToMany(mappedBy = "test")
	List<StudentTest> tests;

	public Test() {

	}
	
	public Test(String testName, int noOfQuestions, int totalMarks, String domain) {
		super();
		this.testName = testName;
		this.noOfQuestions = noOfQuestions;
		this.totalMarks = totalMarks;
		this.domain = domain;
	}







	public int getTestId() {
		return testId;
	}

	public void setTestId(int testId) {
		this.testId = testId;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public int getNoOfQuestions() {
		return noOfQuestions;
	}

	public void setNoOfQuestions(int noOfQuestions) {
		this.noOfQuestions = noOfQuestions;
	}

	public int getTotalMarks() {
		return totalMarks;
	}

	public void setTotalMarks(int totalMarks) {
		this.totalMarks = totalMarks;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public List<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}

	@Override
	public String toString() {
		return "Test [testId=" + testId + ", testName=" + testName + ", noOfQuestions=" + noOfQuestions
				+ ", totalMarks=" + totalMarks + ", domain=" + domain + "]";
	}
	
}
