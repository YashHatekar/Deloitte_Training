package com.project.demo.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.demo.model.Student;
import com.project.demo.model.Test;
import com.project.demo.controllers.TestRepository;

@Controller
public class TestController {
	
	@Autowired
	private TestRepository testRepo;
	
	@Autowired
	private  StudentRepository studRepo;
	
	@PostMapping("/displayMarks")
	public String getMarks(Model model, @RequestParam int findtestId) {
		/*
		 * List<String> attribute = new ArrayList<>(); attribute.add((String)
		 * model.getAttribute("findtestId"));
		 * attribute.add(studRepo.findAll().toString());
		 * attribute.add(studRepo.findAll().toString());
		 */
		System.out.println(testRepo.findById(findtestId));
		
		model.addAttribute("marks",  testRepo.findById(findtestId).get());
		model.addAttribute("mark", new Test());
		return "testsResult";
	}
	
	
	
	@GetMapping("/tests")
	public String findTest(Model model) {
		model.addAttribute("Tests", testRepo.findAll());
		return "tests";
	}
	
	@GetMapping("/testsResult")
	public String findTestResult(Model model) {
	
		model.addAttribute("Tests", testRepo.findAll());
		return "testsResult";
	}
	
	
	@PostMapping("/testcreate")
	public String saveTest(@Valid Test test) {
		testRepo.save(test);
		return "redirect:/tests";
	}
	
	@GetMapping("/Tests/{id}")
	public Optional<Test> getTestById(@PathVariable(value="id") Long testId,Model m,@RequestParam int findtestId){
		m.addAttribute("testbyId",  testRepo.findById(findtestId));
		return testRepo.findById(findtestId);
	}

	@PutMapping("/Tests/{id}")
	public Test updateTest(@PathVariable(value="id") Integer testId, @Valid @RequestBody Test t){
		Optional<Test> test=testRepo.findById(testId);
		if(test.isPresent()) {
			test.get().setTestName(t.getTestName());
			test.get().setNoOfQuestions(t.getNoOfQuestions());
			test.get().setTotalMarks(t.getTotalMarks());
			test.get().setDomain(t.getDomain());

			t=testRepo.save(test.get());
		}
		return t;
	}

	@DeleteMapping("/Tests/{id}")
	public ResponseEntity<?> deleteTest(@PathVariable(value="id")Integer testId){
		Optional<Test> test=testRepo.findById(testId);
		if(test.isPresent()) {
			testRepo.delete(test.get());
		}
		return ResponseEntity.ok().build();
	}

}
