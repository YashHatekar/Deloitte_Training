package com.project.demo.controllers;
import org.springframework.data.repository.CrudRepository;

import com.project.demo.model.StudentTest;
import com.project.demo.model.StudentTestKey;


public interface StudentTestRepository extends CrudRepository<StudentTest, StudentTestKey> {


}
