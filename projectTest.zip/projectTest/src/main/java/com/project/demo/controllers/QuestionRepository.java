package com.project.demo.controllers;

import org.springframework.data.repository.CrudRepository;

import com.project.demo.model.Question;

public interface QuestionRepository extends CrudRepository<Question, Integer>{

}
