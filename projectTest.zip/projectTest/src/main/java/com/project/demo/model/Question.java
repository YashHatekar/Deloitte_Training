package com.project.demo.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.project.demo.model.Test;

@Entity
@Table(name = "project_question")
public class Question {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PROJECT_QUESTION_SEQ")
	@SequenceGenerator(sequenceName = "question_seq", allocationSize = 1, name = "PROJECT_QUESTION_SEQ")
	@Column(name = "QUESID")
	private int quesId;

	@ManyToMany(mappedBy = "questions")
	private List<Test> tests;

	@Column(name = "QUESTEXT", nullable = false)
	private String quesText;

	@Column(name = "CORRECTANSWER", nullable = false)
	private String correctAnswer;

	@Column(name = "OPTIONA")
	private String optionA;

	@Column(name = "OPTIONB")
	private String optionB;

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	@Column(name = "OPTIONC")
	private String optionC;

	@Column(name = "OPTIOND")
	private String optionD;

	@Column(name = "DOMAIN")
	private String domain;

	public Question() {

	}

	public int getQuesId() {
		return quesId;
	}

	public void setQuesId(int quesId) {
		this.quesId = quesId;
	}

	public List<Test> getTests() {
		return tests;
	}

	public void setTests(List<Test> tests) {
		this.tests = tests;
	}

	public String getQuesText() {
		return quesText;
	}

	public void setQuesText(String quesText) {
		this.quesText = quesText;
	}

	public String getCorrectAnswer() {
		return correctAnswer;
	}

	public void setCorrectAnswer(String correctAnswer) {
		this.correctAnswer = correctAnswer;
	}

	public String getOptionA() {
		return optionA;
	}

	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}

	public String getOptionB() {
		return optionB;
	}

	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}

	public String getOptionC() {
		return optionC;
	}

	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}

	public String getOptionD() {
		return optionD;
	}

	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}

}
