package com.project.demo.controllers;

import com.project.demo.model.QuestionAnswer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import com.project.demo.model.StudentTest;
import com.project.demo.model.StudentTestKey;
import com.project.demo.model.Test;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import java.util.ArrayList;

@Controller
public class StudentTestMarksController {
	List<QuestionAnswer> ansList = new ArrayList<>();

	@Autowired
	StudentTestRepository studtestRepo;

	@Autowired
	StudentRepository studentRepo;

	@Autowired
	TestRepository testRepo;

	@Autowired
	QuestionRepository questRepo;

	@GetMapping("/getMarks")
	public String findMarksData(Model model) {

		model.addAttribute("row", studtestRepo.findAll());
		System.out.println(studtestRepo.findAll());
		model.addAttribute("testMarks", new StudentTest());
		System.out.println(studtestRepo.findAll());
		return "testsResult";
	}

	@GetMapping("/Quiz/{id}/{tid}")
	public String quiz(Model model, @PathVariable(value = "id") int id, @PathVariable(value = "tid") int testId) {
		model.addAttribute("studDetails", studentRepo.findById(id).get());
		model.addAttribute("testDetails", testRepo.findById(testId).get());
		model.addAttribute("questions", questRepo.findAll());
		return "Quiz";
	}

	@GetMapping("/calculateMarks/{id}/{tid}")
	public String calc(@PathVariable(name = "id") int id, @PathVariable(name = "tid") int testId,
	    @RequestParam(name = "questionIds")	Set<Integer> questionIds, HttpServletRequest request,Model m) {
		// calc marks and then save it to db
		int marksCounter=0;
		System.out.println(questionIds);
		List<QnA> qnaList = new ArrayList<>();
		for (Integer qid : questionIds) {
			qnaList.add(new QnA(qid,  request.getParameter(String.valueOf(qid)).trim()) );
		}
		System.out.println(qnaList);
		
		for(QnA qna:qnaList) {
			if(qna.getQid()==questRepo.findById(qna.getQid()).get().getQuesId()) {
				System.out.println(questRepo.findById(qna.getQid()).get().getCorrectAnswer());
				if(qna.getAns().equalsIgnoreCase(questRepo.findById(qna.getQid()).get().getCorrectAnswer())) {
					
					marksCounter++;
				}
			}
		}
		System.out.println(marksCounter);
		m.addAttribute("marks", marksCounter);
		m.addAttribute("totalMarks", testRepo.findById(testId).get().getTotalMarks());
		m.addAttribute("testsDetails", testRepo.findById(testId).get());
		m.addAttribute("sId", id);
		System.out.println("Student -> " + studentRepo.findById(id).get());
		System.out.println("Test -> " + testRepo.findById(testId).get());
		StudentTestKey stk = new StudentTestKey();
		stk.setTestId(id);
		stk.setTestId(testId);
		StudentTest st = new StudentTest();
		st.setId(stk);
		st.setStudent(studentRepo.findById(id).get());
		st.setTest(testRepo.findById(testId).get());
		st.setMarksObtained(marksCounter);
		studtestRepo.save(st);
		System.out.println("ST -> " + st);
		return "marks";
	}
	class QnA{
		int qid;
		String ans;
		
		public QnA(int qid, String ans) {
			this.qid = qid;
			this.ans = ans;
		}
		
		public int getQid() {
			return qid;
		}
		
		
		@Override
		public String toString() {
			return "QnA [qid=" + qid + ", ans=" + ans + "]";
		}

		public String getAns() {
			return ans;
		}
		
	}

}
