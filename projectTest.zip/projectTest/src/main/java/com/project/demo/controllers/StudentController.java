package com.project.demo.controllers;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.project.demo.model.Student;

@Controller
public class StudentController {

	@Autowired
	private StudentRepository studentRepo;
	
	@Autowired
	private TestRepository testRepo;

	@GetMapping("/index")
	public String findStudent(Model model) {
		model.addAttribute("students", studentRepo.findAll());
		model.addAttribute("student", new Student());
		System.out.println("IN INDEX GET");
		return "index";
	}

	@GetMapping("/student/{id}")
	public String login(@PathVariable(value="id") int id,Model model){
		model.addAttribute("student",studentRepo.findById(id));
		return "student_tests";
	}
	
	@GetMapping("/student_tests/{id}")
	public String stud(Model model,@PathVariable(value = "id")int id) {
		System.out.println("IN STUDENT_TESTS GET");
		model.addAttribute("students", studentRepo.findById(id).get());
		model.addAttribute("Tests", testRepo.findAll());

		return "student_tests";
	}

	
	@PostMapping("/student_tests")
	public String studentDash(Student student,Model model) {
		System.out.println(studentRepo.findByStudentIdAndPassword(student.getStudentId(), student.getPassword()));
		List<Student> stud = studentRepo.findByStudentIdAndPassword(student.getStudentId(), student.getPassword());
		if(student.getPassword().equals(stud.get(0).getPassword())&&!student.getPassword().equals("adminpass"))
		{
			System.out.println(student.getPassword().equals(stud.get(0).getPassword()));
			model.addAttribute("studentsGet",stud);
			model.addAttribute("Tests",testRepo.findAll());
			return "redirect:/student_tests/"+student.getStudentId();
		}
		else if(student.getPassword().equals("adminpass")) {
			return "redirect:/tests";
		}
		else {
			System.out.println(student.getPassword().equals(stud.get(0).getPassword()));
			System.out.println("IN STUDENT_TESTS POST ELSE");
			return "redirect:/index";
		}
	}
	
	
	@GetMapping("/signup")
	public String student() {
		return "signup";
	}

	@PostMapping("/signup")
	public String addStudent(Student student) {
		studentRepo.save(student);
		return "redirect:/index";
	}

	@PostMapping("/students/{id}")
	public String deleteStudent(@PathVariable(value = "id") int id) {
		Optional<Student> student = studentRepo.findById(id);
		if (student.isPresent()) {
			studentRepo.delete(student.get());
		}
		return "students";
	}
	
	@GetMapping("/displayStudents")
	public String findAll(Model model) {
		model.addAttribute("studentsFind",studentRepo.findAll());
		return "displayStudents";
	}

}
