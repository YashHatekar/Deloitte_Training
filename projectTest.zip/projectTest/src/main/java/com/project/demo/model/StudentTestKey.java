package com.project.demo.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class StudentTestKey implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "StudentId")
	int studentId;
	
	@Column(name = "TestId")
	int testId;

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public int getTestId() {
		return testId;
	}

	public void setTestId(int testId) {
		this.testId = testId;
	}
	
	
}
