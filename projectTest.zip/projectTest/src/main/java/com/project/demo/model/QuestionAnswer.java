package com.project.demo.model;

public class QuestionAnswer {

    private int questionId;
    private char answerOption;

    QuestionAnswer(){

    }


    public int getQuestionId() {
        return questionId;
    }

    public void setQuestionId(int questionId) {
        this.questionId = questionId;
    }

    public char getAnswerOption() {
        return answerOption;
    }

    public void setAnswerOption(char answerOption) {
        this.answerOption = answerOption;
    }
    @Override
    public String toString() {
        return "QuestionAnswer [questionId=" + questionId + ", answerOption=" + answerOption + "]";
    }
}
