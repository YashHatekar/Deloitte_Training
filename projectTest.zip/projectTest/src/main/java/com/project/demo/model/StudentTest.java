package com.project.demo.model;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

@Entity
@Table(name = "project_StudentTest")
public class StudentTest {

	@EmbeddedId
	private StudentTestKey id;

	@ManyToOne
	@MapsId("studentId")
	@JoinColumn(name = "studentId")
	private Student student;

	@ManyToOne
	@MapsId("testId")
	@JoinColumn(name = "testId")
	private Test test;

	private int marksObtained;

	public StudentTest() {

	}

	
	
	public StudentTest(Student student, Test test, int marksObtained) {
		this.student = student;
		this.test = test;
		this.marksObtained = marksObtained;
	}



	public StudentTestKey getId() {
		return id;
	}

	public void setId(StudentTestKey id) {
		this.id = id;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Test getTest() {
		return test;
	}

	public void setTest(Test test) {
		this.test = test;
	}

	public int getMarksObtained() {
		return marksObtained;
	}

	public void setMarksObtained(int marksObtained) {
		this.marksObtained = marksObtained;
	}

	@Override
	public String toString() {
		return "StudentTest [id=" + id + ", student=" + student + ", test=" + test + ", marksObtained=" + marksObtained
				+ "]";
	}

}
