package crud.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdatePrescription
 */
@WebServlet("/updatePrescription")
public class UpdatePrescription extends HttpServlet {
	int medId = 0;
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdatePrescription() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int prescId = Integer.parseInt(request.getParameter("update"));
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		PrescriptionDao pd = new PrescriptionDao();
		Prescription p = pd.update(prescId);

		out.println("<form method='post' action='updatePrescription'>");
		out.println("Prescription Id: <input type='hidden' name='id' value='" + p.getPrescId() + "' /> ");
		out.println("Patient Id: <input type='text' name='patientId' value='" + p.getPatientId() + "' required/> <br>");
		out.println("Medicine List: <input type='text' name='meds' value='" + p.getmedicines() + "' required/> <br>");
		out.println("Prescribed On: <input type='hidden' name='regDate' value='" + p.getPrescDate() + "' /> ");
		out.println("<button type='submit'>Update</button>");
		out.println("</form>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int prescId = Integer.parseInt(request.getParameter("id"));
		int patientId = Integer.parseInt(request.getParameter("patientId"));
		String meds = request.getParameter("meds");
		String d = request.getParameter("regDate");
		Date date = new java.sql.Date(request.getDateHeader(d));

		Prescription p = new Prescription(prescId, date, patientId, meds);
		PrescriptionDao pd = new PrescriptionDao();
		pd.updatePrescription(p);
		List<Prescription> prescriptions = pd.select();
		request.setAttribute("Prescriptions", prescriptions);
		request.getRequestDispatcher("Homepage.jsp").forward(request, response);
	}

}
