package crud.demo;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Patient {

	@Id
	private int patientId;

	private String patientName;

	private String patientEmail;
	private Date patientRegOn;

	
	
	Patient() {

	}

	public Patient(int patientId, String patientName, String patientEmail, Date patientRegOn) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.patientEmail = patientEmail;
		this.patientRegOn = patientRegOn;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getPatientEmail() {
		return patientEmail;
	}

	public void setPatientEmail(String patientEmail) {
		this.patientEmail = patientEmail;
	}

	public Date getPatientRegOn() {
		return patientRegOn;
	}

	public void setPatientRegOn(Date patientRegOn) {
		this.patientRegOn = patientRegOn;
	}

	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", patientName=" + patientName + ", patientEmail=" + patientEmail
				+ ", patientRegOn=" + patientRegOn + "]";
	}

}
