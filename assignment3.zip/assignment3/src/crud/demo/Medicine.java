package crud.demo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Medicine {

	@Id
	private int medId;
	private String medName;
	
	Medicine() {

	}

	public Medicine(int medId, String medName) {
		super();
		this.medId = medId;
		this.medName = medName;
	}

	public int getMedId() {
		return medId;
	}

	public void setMedId(int medId) {
		this.medId = medId;
	}

	public String getMedName() {
		return medName;
	}

	public void setMedName(String medName) {
		this.medName = medName;
	}

}
