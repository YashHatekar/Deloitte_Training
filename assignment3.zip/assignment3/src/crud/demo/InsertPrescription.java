package crud.demo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InsertPrescription
 */
@WebServlet("/insertPrescription")
public class InsertPrescription extends HttpServlet {
	int prescId = 0;
	int medId = 0;
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public InsertPrescription() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int pId = Integer.parseInt(request.getParameter("id"));
		PrescriptionDao p1 = new PrescriptionDao();
		p1.delete(pId);

		List<Prescription> prescriptions = p1.select();
		request.setAttribute("Prescriptions", prescriptions);
		request.getRequestDispatcher("Homepage.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int pId = Integer.parseInt(request.getParameter("patientId"));
		String[] meds = request.getParameter("meds").split(",");
		List<Medicine> medicines = new ArrayList<Medicine>();
		for (String med : meds) {
			medicines.add(new Medicine(++medId, med));
		}
		Date prescDate = new Date();
		Prescription p1 = new Prescription(++prescId, new java.sql.Date(prescDate.getTime()), pId, medicines);

		PrescriptionDao pd = new PrescriptionDao();
		pd.create(p1);

		List<Prescription> prescriptions = pd.select();
		request.setAttribute("Prescriptions", prescriptions);
		request.getRequestDispatcher("Homepage.jsp").forward(request, response);
	}

}
