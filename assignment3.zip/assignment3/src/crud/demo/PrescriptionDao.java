package crud.demo;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

public class PrescriptionDao {
	private StandardServiceRegistry registry;
	private SessionFactory sessionFactory;

	public void create(Prescription p) {
		try (Session session = getSessionFactory().openSession()) {
			session.getTransaction().begin();
			session.save(p);
			session.getTransaction().commit();
		}
	}

	public List<Prescription> select() {
		try (Session session = getSessionFactory().openSession()) {
			Query<Prescription> query = session.createQuery("select p from Prescription p", Prescription.class);
			List<Prescription> Prescriptions = query.getResultList();
			return Prescriptions;
		}
	}

	public void delete(int id) {
		try (Session session = getSessionFactory().openSession()) {
			session.getTransaction().begin();
			Prescription delPrescription = session.get(Prescription.class, id);
			session.delete(delPrescription);
			session.getTransaction().commit();
		}
	}

	public Prescription update(int id) {
		try (Session session = getSessionFactory().openSession()) {
			session.getTransaction().begin();
			Prescription upPrescription = session.get(Prescription.class, id);
			return upPrescription;
		}
	}

	private SessionFactory getSessionFactory() {
		if (sessionFactory == null) {
			registry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources sources = new MetadataSources(registry);
			Metadata metadata = sources.getMetadataBuilder().build();
			sessionFactory = metadata.getSessionFactoryBuilder().build();

		}
		return sessionFactory;
	}

	public void shutdown() {
		if (registry != null) {
			StandardServiceRegistryBuilder.destroy(registry);
		}
	}

	public void updatePrescription(Prescription upPrescription) {
		try (Session session = getSessionFactory().openSession()) {
			session.getTransaction().begin();
			session.update(upPrescription);
			session.getTransaction().commit();
		}
	}
}
