package crud.demo;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

public class PatientDao {

	private StandardServiceRegistry registry;
	private SessionFactory sessionFactory;

	public void create(Patient p) {
		try (Session session = getSessionFactory().openSession()) {
			session.getTransaction().begin();
			session.save(p);
			session.getTransaction().commit();
		}
	}

	public List<Patient> select() {
		try (Session session = getSessionFactory().openSession()) {
			Query<Patient> query = session.createQuery("select p from Patient p", Patient.class);
			List<Patient> Patients = query.getResultList();
			return Patients;
		}
	}

	public void delete(String email) {
		try (Session session = getSessionFactory().openSession()) {
			session.getTransaction().begin();
			Patient delPatient = session.get(Patient.class, email);
			session.delete(delPatient);
			session.getTransaction().commit();
		}
	}

	public Patient update(String email) {
		try (Session session = getSessionFactory().openSession()) {
			session.getTransaction().begin();
			Patient upPatient = session.get(Patient.class, email);
			return upPatient;
		}
	}

	private SessionFactory getSessionFactory() {
		if (sessionFactory == null) {
			registry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources sources = new MetadataSources(registry);
			Metadata metadata = sources.getMetadataBuilder().build();
			sessionFactory = metadata.getSessionFactoryBuilder().build();

		}
		return sessionFactory;
	}

	public void shutdown() {
		if (registry != null) {
			StandardServiceRegistryBuilder.destroy(registry);
		}
	}

	public void updatePatient(Patient upPatient) {
		try (Session session = getSessionFactory().openSession()) {
			session.getTransaction().begin();
			session.update(upPatient);
			session.getTransaction().commit();
		}
	}
}
