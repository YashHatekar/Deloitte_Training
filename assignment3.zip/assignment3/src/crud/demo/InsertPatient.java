package crud.demo;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class insert
 */
@WebServlet("/insertPatient")
public class InsertPatient extends HttpServlet {
	int id = 0;
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public InsertPatient() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String pEmail = request.getParameter("email");
		PatientDao p1 = new PatientDao();
		p1.delete(pEmail);

		List<Patient> patients = p1.select();
		request.setAttribute("Patients", patients);
		request.getRequestDispatcher("Homepage.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String pName = request.getParameter("name");
		String pEmail = request.getParameter("email");
		Date registered_on = new Date();
		Patient p1 = new Patient(++id, pName, pEmail, new java.sql.Date(registered_on.getTime()));

		PatientDao pd = new PatientDao();
		pd.create(p1);
		List<Patient> patients = pd.select();
		request.setAttribute("Patients", patients);
		request.getRequestDispatcher("Homepage.jsp").forward(request, response);
	}

}
