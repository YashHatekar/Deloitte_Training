package crud.demo;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Prescription {

	@Id
	private int prescId;
	
	private Date prescDate;

	
	private int patientId;


	private String medicines;
	
	
	private int medId;

	
	Prescription() {

	}

	public Prescription(int prescId, Date prescDate, int patientId, String medList) {
		super();
		this.prescId = prescId;
		this.prescDate = prescDate;
		this.patientId = patientId;
		this.medicines = medList;
	}

	public int getPrescId() {
		return prescId;
	}

	public void setPrescId(int prescId) {
		this.prescId = prescId;
	}

	public Date getPrescDate() {
		return prescDate;
	}

	public void setPrescDate(Date prescDate) {
		this.prescDate = prescDate;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getmedicines() {
		return medicines;
	}

	public void setmedicines(String medList) {
		this.medicines = medList;
	}

	@Override
	public String toString() {
		return "Prescription [prescId=" + prescId + ", prescDate=" + prescDate + ", patientId=" + patientId
				+ ", medList=" + medicines + "]";
	}

}
